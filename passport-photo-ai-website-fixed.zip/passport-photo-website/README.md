# Passport Photo AI

A one-click website: upload a photo and the server applies the fixed passport-photo editing prompt.

## Requirements
- Node.js 18+
- An OpenAI API key with access to image generation/editing

## Run
1. Open a terminal in this folder.
2. Run `npm install`
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env`:
   `OPENAI_API_KEY=your_key_here`
5. Run `npm start`
6. Open `http://localhost:3000`

## Important
The API key must stay on the server. Do not put it into `public/index.html`.

The fixed prompt is built into `server.mjs`; the user does not need to enter a prompt.
