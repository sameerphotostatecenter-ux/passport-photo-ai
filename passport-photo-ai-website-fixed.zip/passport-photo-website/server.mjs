import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import OpenAI, { toFile } from 'openai';
import fs from 'node:fs/promises';
import path from 'node:path';

const app = express();
const port = Number(process.env.PORT || 3000);
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

if (!process.env.OPENAI_API_KEY) {
  console.warn('OPENAI_API_KEY is not set. Add it to .env before using the generator.');
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const PROMPT = `Create a realistic passport-size photo of the same person in the image. Keep the face, expression, and all facial features completely unchanged. Replace the current outfit with a professional suit and tie suitable for official documents. Maintain a clean white background, natural lighting, and correct proportions for a passport photo.`;

app.use(express.static(path.join(process.cwd(), 'public')));

app.post('/api/generate', upload.single('image'), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: 'OPENAI_API_KEY is not configured on the server.' });
    if (!req.file) return res.status(400).json({ error: 'Please select an image.' });
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(req.file.mimetype)) {
      return res.status(400).json({ error: 'Please upload a PNG, JPG/JPEG, or WebP image.' });
    }

    const input = await toFile(req.file.buffer, req.file.originalname, { type: req.file.mimetype });
    const result = await client.images.edit({
      model: 'gpt-image-1',
      image: input,
      prompt: PROMPT,
      size: '1024x1536',
      quality: 'high',
      background: 'opaque',
      output_format: 'png'
    });

    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error('The image API returned no image data.');
    res.json({ image: `data:image/png;base64,${b64}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || 'Image generation failed.' });
  }
});

app.listen(port, () => console.log(`Passport Photo AI running at http://localhost:${port}`));
